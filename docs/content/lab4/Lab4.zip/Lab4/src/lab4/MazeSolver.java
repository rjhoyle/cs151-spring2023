package lab4;

import java.util.*;

abstract class MazeSolver {
    public static final int STACK = 1, QUEUE = 2;
    protected Maze maze;
    protected boolean finished = false;
    protected boolean pathFound = false;

    MazeSolver(Maze maze) {
        this.maze = maze;
    }

    abstract void makeEmpty();

    abstract boolean isEmpty();

    abstract void add(Square sq);

    abstract Square next();

    public boolean isFinished() {
        return finished;
    }

    public boolean pathFound() {
        return pathFound;
    }

    /*
     * makes a list of the squares on a path from the start square to the exit
     * square
     */
    public List<Square> getPath() {
        // TODO: write the getPath method
        return new ArrayList<Square>(); // replace this line
    }

    /* performs one step of the maze solver algorithm */
    public void step() {
        // TODO: code goes here
    }
}
