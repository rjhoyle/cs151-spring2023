
/**
 * TODO - your comments here
 */

package lab5;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class MyLinkedList<T> extends AbstractList<T> {
	Node head, tail;
	int size;

	protected class Node {
		T data;
		Node next;
		Node prev;

		protected Node() {
			data = null;
			next = null;
			prev = null;
		}
	}

	public MyLinkedList() {
		head = new Node();
		tail = new Node();
		head.next = tail;
		tail.prev = head;
		size = 0;
	}
}
