package lab2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeSet;

public class CollectionsTest {
    public static int MAX_SIZE = 50000;
    public static int NUM_TESTS = 10;

    public static long TimeAdd(Collection<Integer> c) {
        // TODO: Implement this method.
        long timeTaken = 0;

        return timeTaken;
    }

    public static long TimeContains(Collection<Integer> c) {
        // TODO: Implement this method.
        long timeTaken = 0;

        return timeTaken;
    }

    public static void TestCollection(Collection<Integer> c) {
        // TODO: Implement this method.

        // You must create an array of the appropriate size
        long[] tests = null;

        // Terminate by printing your results
    }

    public static void main(String[] args) {
        Collection<Integer> c;

        c = new ArrayList<Integer>();
        TestCollection(c);
        c = new TreeSet<Integer>();
        TestCollection(c);
    }

}