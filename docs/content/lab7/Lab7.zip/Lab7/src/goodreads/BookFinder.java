/* 
 * This uses a dataset from the GoodReads website. 
 * You can find the original data file at 
 *     https://www.kaggle.com/jealousleopard/goodreadsbooks 
 * I cut this down to 5 columns: isbn, authors, title, publisher, GoodReads rating.
 * I also cleaned up the data a bit; there were a few broken entries.
 * Note that the file is written with the UTF-8 character encoding. This is the default
 * for Python but needs to be specified for Java, as in 
 * 	new Scanner( new File(foo), "UTF-8" )
 */

package goodreads;

import java.util.ArrayList;
import java.util.List;

/**
 * A BookFinder class holds mappings between ISBNs, titles, authors, and
 * publishers to books represented by a {@link BookData}.
 * 
 * @author Bob Geitz
 * @author Stephen Checkoway
 * @author Your names here...
 * @version 2021-06-30
 * 
 */
public class BookFinder {
    private MyTreeMap<String, BookData> isbnToData;
    private MyTreeMap<String, ArrayList<BookData>> titleToData;
    private MyTreeMap<String, ArrayList<BookData>> authorToData;
    private MyTreeMap<String, ArrayList<BookData>> publisherToData;

    /**
     * Creates a BookFinder object by reading the data file at path.
     * 
     * This will be a comma-separated text file with 5 fields per line:
     * isbn,authors,title,publisher,rating
     * 
     * Multiple authors are separated by '/' characters: Frank Herbert/Domingo
     * Santos
     * 
     * @param path The file path for the input data file.
     */
    public BookFinder(String path) {
        /*
         * You need to open the data file with a "UTF-8" flag, as in
         * 
         * Scanner scan = new Scanner(new File(path), "UTF-8");
         *
         * For each line of the data file you should create a new BookData with the
         * relevant fields. Add the newly created BookData to isbnToData with the isbn
         * as the key.
         * 
         * For the other maps, add the BookData to the ArrayList stored in the map with
         * the appropriate key (title, author, or publisher). If a book has multiple
         * authors, then each author's list should contain the BookData.
         */
    }

    /**
     * Returns a list of books written by the author.
     * 
     * @param author The author to search for.
     * @return A list of {@link BookData} objects written by author.
     */
    public List<BookData> searchByAuthor(String author) {
        /* Implement this. */
        return null;
    }

    /**
     * Returns a list of books with the exact title.
     * 
     * @param title The title to search for.
     * @return A list of {@link BookData} objects with the given title.
     */
    public List<BookData> searchByTitle(String title) {
        /* Implement this. */
        return null;
    }

    /**
     * Returns a list of books published by publisher.
     * 
     * @param publisher The publisher to search for.
     * @return A list of {@link BookData} published by the publisher.
     */
    public List<BookData> searchByPublisher(String publisher) {
        /* Implement this. */
        return null;
    }

    /**
     * Returns a book corresponding to an ISBN, or null if no such book is in the
     * database.
     * 
     * @param isbn The ISBN to search for.
     * @return A {@link BookData} corresponding to the isbn, or null.
     */
    public BookData searchByIsbn(String isbn) {
        /* Implement this. */
        return null;
    }
}
