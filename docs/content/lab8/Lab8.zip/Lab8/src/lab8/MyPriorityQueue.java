/**
 * TODO - add some comments here.
 *
 * @author Benjamin Kuperman (Spring 2011), Cynthia Taylor (Summer 2021)
 * @author YOU!
 */
package lab8;

import java.util.AbstractQueue;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class MyPriorityQueue<AnyType> extends AbstractQueue<AnyType> {

    /** Item to use for making comparisons */
    private Comparator<? super AnyType> cmp;

    /** ArrayList for the heap itself */
    private ArrayList<AnyType> heap;

    public Comparator<? super AnyType> comparator() {

    }

    public int size() {

    }

    public void clear() {

    }

    public boolean offer(AnyType o) {

    }

    public AnyType peek() {

    }

    public AnyType poll() {

    }

    public Iterator<AnyType> iterator() {

    }

    /**
     * Construct a heap with a given comparator.
     * 
     * @param cmp Comparator to use for ordering nodes
     */
    public MyPriorityQueue(Comparator<? super AnyType> cmp) {

    }

    private void percolateDown(int hole) {

    }

    private void percolateUp(int hole) {

    }

    /**
     * Calculate the parent index of a node in a complete binary tree
     * 
     * @param index node to find parent index of
     * @return index of parent or -1 if there is no parent
     */
    private int parent(int index) {

    }

    /**
     * Calculate the index for the left child of the given index in a complete
     * binary tree.
     * 
     * @param index node to find left child of
     * @return index of left child or -1 if there is no left child
     */
    private int lchild(int index) {

    }

    /**
     * Calculate the index for the right child of the given index in a complete
     * binary tree.
     * 
     * @param index node to find right child of
     * @return index of right child or -1 if there is no right child
     */
    private int rchild(int index) {

    }

}
